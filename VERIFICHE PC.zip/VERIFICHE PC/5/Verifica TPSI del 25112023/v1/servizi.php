<?php
    $servizi = array(
    array("Scegli Servizio", 1000, 1000,) ,
    array("Campo calcetto", 1, 80,) ,
    array("Campo basket", 1,  100,) ,
    array("Campo padel", 1,  50,),
    array("Campo squash", 1,  20,),
    array("Campo tennis", 2, 40,),
    array("Ring da combattimento", 2, 50,),
    array("Sala cinema", 2, 100,),
    array("Pacchetto massaggi cervicali", 2, 20),
    array("Pacchetto massaggi piedi", 2, 20),
    array("Pacchetto massaggi arti inferiori", 3, 30),
    array("Pacchetto massaggi completo", 5, 40),
    array("Pacchetto accesso area fitness", 10, 10),
    array("Pacchetto accesso area relax", 5, 10)
    );
?>
